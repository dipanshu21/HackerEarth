package com.ProjectEuler;

import java.util.ArrayList;

/**
 * Created by deepanshu on 30/04/16, 8:28 AM.
 */
class NumberUtil {

    public static boolean isPalindrome(long num) {
        long c = num;
        long r = 0;
        while (num != 0) {
            r = (r * 10) + (num % 10);
            num /= 10;
        }

        return c == r;
    }

    public static boolean isPalindrome(int num) {
        return isPalindrome((long) num);
    }

    public static int getNumOfDivisors(int n, ArrayList<Long> primes) {
        int lim = (int) Math.sqrt(n);

        int divisor = 1;

        for(int i = 0; i < primes.size(); i++){
            int c = 0;
            long curPrime = primes.get(i);
            if(curPrime < lim){
                while (n%curPrime == 0){
                    n /= curPrime;
                    c++;
                }
                divisor *= c+1;
                if(n == 1){
                    break;
                }
            } else {
                break;
            }
        }

        return divisor;
    }

    public static int getSumOfDivisors(int n) {
        int lim = (int) Math.sqrt(n);

        int sum = 1 + (n%lim == 0? (lim*lim == n? lim: lim + n/lim): 0);

        for(int i = 2; i < lim; i++){
            if(n%i == 0){
                sum += i + n/i;
            }
        }

        return sum;
    }

    public static int getSumOfDivisorsUsingPrimeFactorisation(int n, ArrayList<Long> primes) {
        int lim = (int) Math.sqrt(n);
        int divisor = 1;

        for(int i = 0; i < primes.size(); i++){
            int c = 0;
            long curPrime = primes.get(i);
            long curPrimePow = 1;
            if(curPrime <= lim){
                while (n%curPrime == 0){
                    n /= curPrime;
                    curPrimePow *= curPrime;
                    c++;
                }

                if(c != 0) {
                    curPrimePow *= curPrime;
                    divisor *= (curPrimePow - 1) / (curPrime - 1);
                }

                if(n == 1){
                    break;
                }
            } else {
                break;
            }
        }

        return divisor;
    }

    public static ArrayList<int[]> getPrimeFactorisation(int n, ArrayList<Long> primes) {
        ArrayList<int[]> factors = new ArrayList<>();
        int lim = (int) Math.sqrt(n);
        for(int i = 0; i < primes.size(); i++){
            int c = 0;
            long curPrime = primes.get(i);
            if(curPrime <= n){
                while (n%curPrime == 0){
                    n /= curPrime;
                    c++;
                }

                if(c != 0) {
                    factors.add(new int[] {(int)curPrime, c});
                }

                if(n == 1){
                    break;
                }
            } else {
                break;
            }
        }

        return factors;
    }
}
