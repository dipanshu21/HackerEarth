package com.ProjectEuler;

import java.util.ArrayList;

/**
 * Created by deepanshu on 30/04/16, 8:05 AM.
 */
class PrimeUtil {
    public static ArrayList<Long> primes = new ArrayList<>(1000);

    public static long getNextPrime() {
        if (primes.isEmpty()) {
            primes.add(2l);
            return 2;
        } else {
            long i = primes.get(primes.size() - 1) + 1;
            boolean isPrimeFound = false;

            while (!isPrimeFound) {
                int j = 0;
                long curNum = primes.get(j);
                final int sqr = (int)Math.sqrt(i);

                boolean isDivided = false;
                while(curNum <= sqr && j < primes.size()){
                    if(i%curNum == 0){
                        isDivided = true;
                        break;
                    }
                    j++;
                    curNum = primes.get(j);
                }

                if(!isDivided){
                    isPrimeFound = true;
                } else {
                    i++;
                }

            }

            primes.add(i);
            return i;
        }
    }

    public static void clear() {
        primes.clear();
    }

    public static void main(String[] args){
        for(int i = 0; i < 10001; i++) {
            System.out.println(PrimeUtil.getNextPrime());
        }
    }

    public static void generatePrimesUptoN(long n) {
        primes.clear();
        long i = getNextPrime();
        while(i < n){
            i = getNextPrime();
        }
    }

    public static void generatePrimesUptoNSieve(int n) {
        primes.clear();
        primes = new ArrayList<>(n/1000);
        boolean[] sieve = new boolean[n];

        for(int i = 2; i < sieve.length; i++) {
            if(!sieve[i]) {
                primes.add((long)i);

                int j = 2;
                while (j*i < sieve.length) {
                    sieve[j*i] = true;
                    j++;
                }
            }
        }
    }
}
