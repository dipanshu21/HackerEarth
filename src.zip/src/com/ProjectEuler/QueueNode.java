package com.ProjectEuler;

/**
 * Created by deepanshu on 25/04/16, 11:11 AM.
 */
class QueueNode {
    long data;
    QueueNode next;

    public QueueNode(long d){
        data = d;
        next = null;
    }
}

class Queue {
    QueueNode head, last;
    final long k;
    long c = 0;

    public Queue(long n, long k) {
        this.k = k;
        head = last = new QueueNode(n);
    }

    public long peek(){
        try {
            long data = head.data;
            c++;
            if (c == k) {
                delete();
                c = 0;
            }
            return data;
        } catch (Exception e){
            System.out.println();
        }

        return 0;
    }

    private void delete(){
        head = head.next;
        if(head == null){
            last = null;
        }
    }

    public void add(long n){
        if(head == null){
            head = last = new QueueNode(n);
            return;
        }
        last.next = new QueueNode(n);
        last = last.next;
    }
}
